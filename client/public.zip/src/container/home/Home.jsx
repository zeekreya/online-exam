import styles from "./Home.module.css"
import Header from "../../components/header/Header";
import { Form, Button, FloatingLabel, Dropdown } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { House, Gear, Bell, Person, Eye, EyeSlash, Plus, Trash } from 'react-bootstrap-icons';
import { PlusCircle, Pencil } from 'react-bootstrap-icons';
import axios from "axios";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';


const Home = () => {
    const navigate = useNavigate();
    let [exam, setExam] = useState("");


    return (
        <div className="vh-100 vw-100  d-flex justify-content-start align-items-center flex-column " style={{ position: "relative" }} >
            <Header />
            <div className="row w-100 h-25">
                <div className="p-1 col-md-4 h-100">
                    <div className=" h-100 w-100  bg-success d-flex justify-content-center align-itmes-center rounded rounded-4 shadow flex-column" >
                        <p className="display-2 text-center" onClick={() => navigate("/exam")} >Exams</p>
                        <p className="display-4 text-center">0</p>
                    </div>
                </div>

                <div className="p-1 col-md-4 h-100">
                    <div className=" h-100 w-100  bg-primary d-flex justify-content-center align-itmes-center rounded rounded-4 shadow flex-column" >
                        <p className="display-2 text-center" >Questions</p>
                        <p className="display-4 text-center">0</p>
                    </div>
                </div>
                <div className="p-1 col-md-4 h-100">
                    <div className=" h-100 w-100  bg-warning d-flex justify-content-center align-itmes-center rounded rounded-4 shadow flex-column" >
                        <p className="display-2 text-center" >Results</p>
                        <p className="display-4 text-center">0</p>
                    </div>
                </div>
            </div>
            
            <div className="row w-100 p-1 h-75">
                <div className=" h-100 col-md-12 bg-light d-flex justify-content-center align-itmes-center rounded rounded-4 shadow">
                    <p className="display-6 text-center  " >Upcomming Exams</p>
                </div>
            </div>

            <Button variant="light" style={{ position: "absolute", right: "5%", bottom: 50 }}    ><PlusCircle size={40} color="green" /></Button>

        </div>
    )
}
export default Home;