import styles from "./Result.module.css";
import { Form, Button, FloatingLabel } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { AiOutlineEye, AiOutlineEyeInvisible } from "react-icons/ai";
import { Stack } from 'react-bootstrap';
import { House, Gear, Bell, Person, Eye, EyeSlash, Plus, Trash } from 'react-bootstrap-icons';
import { PlusCircle, Pencil } from 'react-bootstrap-icons';
import Header from "../../components/header/Header";


const Result = () => {
    const navigate = useNavigate();


    let [password, setPassword] = useState("");
    let [email, setEmail] = useState("");
    let [username, setUsername] = useState("");
    let [exam, setExam] = useState("");
    let [showPassword, setShowPassword] = useState(false);
    return (
        <div className={styles?.resultMain}>
         <Header/>

            <div className={`${styles?.resultContainer} shadow border rounded`}>
                <div className={styles?.resultBox}>
                <p className={styles?.resultText}>Results</p>
                <Form className={styles?.resultForm}>
                    <FloatingLabel
                        controlId="floatingInput"
                        label="User Name"
                        className="mb-3"
                    >
                        <Form.Control type="name" placeholder="username" onChange={(e) => setUsername(e.target.value)} />
                    </FloatingLabel>
                    <FloatingLabel
                        controlId="floatingInput"
                        label="Email address"
                        className="mb-3"
                    >
                        <Form.Control type="email" placeholder="name@example.com" onChange={(e) => setEmail(e.target.value)} />
                    </FloatingLabel>
                    <FloatingLabel
                        controlId="floatingInput"
                        label="Exam Name"
                        className="mb-3"
                    >
                        <Form.Control type="exam" placeholder="Exam" onChange={(e) => setExam(e.target.value)} />
                    </FloatingLabel>
                    <FloatingLabel controlId="floatingPassword" label="Password">
                        <Form.Control type={showPassword ? "text" : "password"} placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
                        <p onClick={() => setShowPassword(!showPassword)} className={styles?.passwordToggle}>
                            {showPassword ? <AiOutlineEye size={25} color="blue" /> : <AiOutlineEyeInvisible size={25} color="red" />}
                        </p>
                    </FloatingLabel>
                    <Button variant="primary" type="submit" className={styles?.resultBtn}>
                        Check Result
                    </Button>
                    <Button variant="warning" type="button" className={styles?.resultBtn} onClick={() => navigate("/home")}>
                       Home
                    </Button>


                </Form>
                </div>
            </div>
        </div>
    )
}
export default Result;