import styles from "./Exam.module.css"
import Header from "../../components/header/Header";
import { Form, Button, FloatingLabel, Dropdown } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { House, Gear, Bell, Person, Eye, EyeSlash, Plus, Trash } from 'react-bootstrap-icons';
import { PlusCircle, Pencil } from 'react-bootstrap-icons';
import axios from "axios";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
    

const Exam = () => {
    const navigate = useNavigate();
    let [exam, setExam] = useState("");


    return (
        <div className="vh-100 vw-100  d-flex justify-content-start align-items-center flex-column " className={styles.examMain} style={{ position: "relative" }} >
            <Header />
            <div className="row w-50 h-100 rounded shadow d-flex justify-content-center align-items-center p-3">
               
               
                    <div  className="  w-100  bg-light d-flex justify-content-center align-itmes-center  shadow flex-column rounded mb-2 " >
                        <p  className={styles?.examText} >Name of the exams</p>
                      
                    </div>
                    <div className="  w-100  bg-light d-flex justify-content-center align-itmes-center  shadow flex-column rounded m-2 "  >
                        <p className="display-6 text-start"  >1.</p>
                    
                    </div>
                    <div  className=" w-100  bg-light d-flex justify-content-center align-itmes-center  shadow flex-column rounded  m-2" >
                        <p className="display-6 text-start">2.</p>
                      
                    </div>
                    <div  className=" w-100  bg-light d-flex justify-content-center align-itmes-center  shadow flex-column  rounded  m-2"  >
                        <p className="display-6 text-start" >3.</p>
                        
                    </div>
                    <div className="  w-100  bg-light d-flex justify-content-center align-itmes-center  shadow flex-column rounded m-2 "  >
                        <p className="display-6 text-start"  >1.</p>
                    
                    </div>
                    <div  className=" w-100  bg-light d-flex justify-content-center align-itmes-center  shadow flex-column rounded  m-2" >
                        <p className="display-6 text-start">2.</p>
                      
                    </div>
                    <div  className=" w-100  bg-light d-flex justify-content-center align-itmes-center  shadow flex-column  rounded  m-2"  >
                        <p className="display-6 text-start" >3.</p>
                        
                    </div>

                    
              

            </div>

            <Button variant="light" style={{ position: "absolute", right: "5%", bottom: 50 }}    ><PlusCircle size={40} color="green" /></Button>

        </div>
    )
}
export default Exam;