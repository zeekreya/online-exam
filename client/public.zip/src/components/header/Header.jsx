import styles from "./Header.module.css"
import { Button, Container, Nav, Navbar } from 'react-bootstrap';
import { useNavigate, NavLink } from 'react-router-dom'; // Changed Link to NavLink

const Header = () => {
    let navigate = useNavigate();
    
    // Style helper to keep the code clean
    const navLinkStyle = ({ isActive }) => ({
        textDecoration: "none",
        color: isActive ? "black" : "grey",
        borderBottom: isActive ? "2px solid red" : "none",
        paddingBottom: "5px"
    });

    return (
        <div style={{ height: "15vh" }} className="vw-100 p-1 pb-3">
            <Navbar collapseOnSelect expand="lg" className="bg-light h-100 border border-1 shadow shadow-color-primary">
                <Container fluid>
                    <img 
                            src="/logo.png" 
                            alt="Logo" 
                            style={{ height: "80px", width: "auto", marginRight: "10px" }} 
                        />
                    <Navbar.Brand >Online Exam</Navbar.Brand>
                    <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                    <Navbar.Collapse id="responsive-navbar-nav">
                        <Nav className="me-auto">
                            {/* Use 'end' on the home route so it doesn't highlight for every sub-route */}
                            <NavLink className='fs-5 p-3' style={navLinkStyle} to="/home/" end>Home</NavLink>
                            <NavLink className='fs-5 p-3' style={navLinkStyle} to="/exam">Exam</NavLink>
                            <NavLink className='fs-5 p-3' style={navLinkStyle} to="/Result">Result</NavLink>
                            <NavLink className='fs-5 p-3' style={navLinkStyle} to="/question">Question</NavLink>
                            <NavLink className='fs-5 p-3' style={navLinkStyle} to="/profile">Profile</NavLink>
                        </Nav>
                        <Nav className="align-items-center">
                            <p className='h3 pe-2 mb-0'>{JSON.parse(localStorage.getItem("userData"))?.name}</p>
                            <Button variant='danger' onClick={() => {
                                localStorage.clear();
                                navigate("/");
                            }}>Logout</Button>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
        </div>
    );
}
export default Header;